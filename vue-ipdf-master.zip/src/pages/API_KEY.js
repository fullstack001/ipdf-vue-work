export const API_KEY = "AIzaSyB2Yno10-YTnLjjn_Vtk0V8cdcY5lC4plU";
