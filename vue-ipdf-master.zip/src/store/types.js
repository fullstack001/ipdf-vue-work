export const SetResult = "setresult";
export const Decrement = "decrement";
