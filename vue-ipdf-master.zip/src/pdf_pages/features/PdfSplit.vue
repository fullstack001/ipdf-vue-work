<template>
  <div class="main">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
    />

    <div class="dropzone-container" @dragover.prevent @drop="handleDrop">
      <div class="upload_btn_area">
        <div v-show="!pages.length" class="upload-buttons">
          <div class="page-title">Split PDF file</div>
          <div class="page-description">
            Separate one page or a whole set for easy conversion into
            independent PDF files.
          </div>
          <div class="upload_btn">
            <label for="fileInput" class="uploader__btn md-raised md-danger">
              Select PDF files
            </label>
            <input
              type="file"
              name="file"
              id="fileInput"
              class="hidden-input"
              @change="onChange"
              ref="file"
              accept=".pdf"
            />
          </div>
        </div>
        <div
          class="add-more"
          v-bind:style="
            pages.length
              ? 'display:none'
              : 'position: relative; margin: auto; right: 0; top: 0;'
          "
        >
          <div v-bind:style="'display: inline-block;'">
            <button class="social_btn" @click="open_add_driver">
              <md-icon>add_to_drive</md-icon>
            </button>
          </div>

          <VueDropboxPicker
            class="cloud dropbox inline-block"
            :api-key="'w7vvdh8a5g5av1p'"
            link-type="direct"
            :multiselect="false"
            :extensions="['.pdf', '.doc']"
            :folderselect="false"
            @picked="onPickedDropbox"
          />
        </div>
      </div>
      <div class="files-list">
        <div class="preview-container mt-4" v-if="pages.length">
          <draggable
            v-model="pages"
            :options="{ animation: 150 }"
            class="md-layout"
          >
            <div class="range__container" v-for="page in pages" :key="page.id">
              <div v-show="extractEdit && showFlag(page.id)">
                <md-badge class="md-primary" md-position="top" md-content="*" />
              </div>
              <div v-show="!extractEdit">
                <p>Range{{ page.id }}</p>
              </div>
              <div class="split_card" v-if="page.range[0] == page.range[1]">
                <div class="split_card_body">
                  <div>
                    <PdfViewer
                      :fileUrl="generateURL(file)"
                      :pageNumber="page.range[0] * 1"
                    />
                  </div>
                  <div class="page_number">{{ page.range[1] }}</div>
                </div>
              </div>
              <div class="split_card" v-else>
                <div class="split_card_body">
                  <div>
                    <PdfViewer
                      :fileUrl="generateURL(file)"
                      :pageNumber="page.range[0] * 1"
                    />
                  </div>
                  <div class="page_number">{{ page.range[0] }}</div>
                </div>
                <div class="split_card_body">
                  <div>
                    <PdfViewer
                      :fileUrl="generateURL(file)"
                      :pageNumber="page.range[1] * 1"
                    />
                  </div>
                  <div class="page_number">{{ page.range[1] }}</div>
                </div>
              </div>
            </div>
          </draggable>
        </div>
      </div>
    </div>

    <div v-show="pages.length">
      <div id="sidebar" class="tool__sidebar" style="overflow-y: auto">
        <h3>Split</h3>
        <div class="tab-area">
          <md-tabs md-alignment="centered">
            <md-tab
              id="tab-home"
              md-icon="picture_as_pdf"
              md-label="Split by range"
              :exact="true"
              @click="rangeSplit"
              v-bind:class="extractEdit ? 'active_tab' : ''"
              :md-template-data="{ badge: 1 }"
              md-active-tab
            >
              <SpiltRange
                :rangeArray="pages"
                :maxNumber="pageCount"
                @rangeChange="changeRange"
              />
            </md-tab>
            <md-tab
              id="Extract pages"
              md-icon="account_tree"
              md-label="Extract Pages"
              @click="extractSplit"
              v-bind:class="extractEdit ? '' : 'active_tab'"
            >
              <SplitExtra :maxNum="pageCount" @extractChange="setExtract" />
            </md-tab>
          </md-tabs>
        </div>

        <div class="option__panel option__panel--active" id="merge-options">
          <button class="option__panel__title" @click="splitPDF">
            Split PDF
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { PDFDocument, degrees } from "pdf-lib";
import PdfViewer from "@/components/PdfViewer.vue";
import VueDropboxPicker from "@/components/DropboxPicker.vue";
import draggable from "vuedraggable";
import SplitExtra from "@/components/SplitExtra.vue";
import SpiltRange from "@/components/SpiltRange.vue";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import store from "@/store/index";
import * as type from "@/store/types";
import axios from "axios";

export default {
  components: {
    PdfViewer,
    VueDropboxPicker,
    draggable,
    SplitExtra,
    SpiltRange,
  },
  data() {
    return {
      isDragging: false,
      file: null,
      pageCount: 0,
      pages: [],
      extractEdit: false,
      extractPages: [],
    };
  },

  methods: {
    //add merged pdf to vuex
    setPdfResult(result) {
      store.dispatch({
        type: type.SetResult,
        amount: result,
      });
    },

    //file from local
    onChange() {
      this.file = this.$refs.file.files[0];
      this.get_pages(this.$refs.file.files[0]);
    },

    //download from dropbox
    onPickedDropbox(data) {
      this.file = data;
      this.get_pages(data);
    },
    changeRange(data) {
      this.pages = data;
    },
    open_add_driver() {
      console.log("google driver");
    },
    get_pages(file) {
      const reader = new FileReader();
      reader.readAsBinaryString(file);
      reader.onloadend = () => {
        const count = reader.result.match(/\/Type[\s]*\/Page[^s]/g).length;
        this.pageCount = count;
        this.pages = [{ id: 1, range: [1, count] }];
        for (let i = 1; i <= count; i++) {
          this.extractPages.push([i, i]);
        }
      };
    },

    handleDrop(event) {
      event.preventDefault();
      const file = event.dataTransfer.files[0];
      if (file) {
        this.file = file;
      }
    },

    setExtract(newExtract) {
      this.extractPages = newExtract;
    },

    //extract split
    extractSplit() {
      this.extractEdit = true;
      this.pages = [];
      for (let i = 1; i <= this.pageCount; i++) {
        this.pages.push({ id: i, range: [i, i] });
      }
    },
    //split as range
    rangeSplit() {
      if (this.extractEdit == true) {
        this.pages = [{ id: 1, range: [1, this.pageCount] }];
        this.extractPages = [];
      }
      this.extractEdit = false;
    },
    showFlag(page) {
      if (!this.extractPages.length) {
        return false;
      } else {
        let budgePages = [];
        for (let i = 0; i < this.extractPages.length; i++) {
          let item = this.extractPages[i];
          if (typeof item == "number") {
            budgePages.push(item);
          } else {
            for (let j = item[0]; j <= item[1]; j++) {
              budgePages.push(j);
            }
          }
        }
        if (budgePages.indexOf(page) < 0) {
          return false;
        } else {
          return true;
        }
      }
    },

    generateURL(file) {
      if (file.link) {
        return file.link;
      } else if (file.type == "application/pdf") {
        let fileSrc = URL.createObjectURL(file);
        setTimeout(() => {
          URL.revokeObjectURL(fileSrc);
        }, 1000);
        return fileSrc;
      }
    },
    async readFileAsync(file) {
      return new Promise((resolve, reject) => {
        let reader = new FileReader();
        reader.onload = () => {
          resolve(reader.result);
        };
        reader.onerror = reject;
        reader.readAsArrayBuffer(file);
      });
    },

    splitPDF() {
      let planPages = [];
      if (this.extractEdit) {
        planPages = this.extractPages;
      } else {
        planPages = this.pages.map((page) => {
          return [page.range[0] * 1, page.range[1] * 1];
        });
      }
      //split PDF
      this.splitingPDF(planPages);
    },

    async splitingPDF(planPages) {
      let splited_temp = planPages.map(async (planPage, index) => {
        const mergedPdf = await PDFDocument.create();
        const file = this.file;
        let pdfBytes = null;

        if (file.link) {
          //dropdown file
          const response = await fetch(file.link);
          const arrayBuffer = await response.arrayBuffer();
          pdfBytes = new Uint8Array(arrayBuffer);
        } else {
          //local upload
          pdfBytes = await this.readFileAsync(file);
        }

        const pdf = await PDFDocument.load(pdfBytes);
        const copiedPages = await mergedPdf.copyPages(
          pdf,
          pdf.getPageIndices()
        );

        if (planPage[0] == planPage[1]) {
          mergedPdf.addPage(copiedPages[planPage[0] - 1]);
        } else {
          for (let i = planPage[0] - 1; i < planPage[1]; i++) {
            mergedPdf.addPage(copiedPages[i]);
          }
        }
        return mergedPdf.save();
      });

      // this.compressed_pdf(urls);
      this.generateZip(splited_temp);
    },

    //create Zip file for download

    async generateZip(pdfFiles) {
      const zip = new JSZip();
      // const pdfFiles = ["file1.pdf", "file2.pdf", "file3.pdf"]; // Replace these with your file names or paths

      const promises = pdfFiles.map(async (data, i) => {
        // // Fetch the PDF file from the server
        // const response = await fetch(file);
        // const data = await response.blob();

        // Add the PDF file to the ZIP
        zip.file(`splited_pdf${i}.pdf`, data);
      });

      Promise.all(promises).then(() => {
        zip.generateAsync({ type: "blob" }).then((content) => {
          //save on vuex
          this.setPdfResult(content);

          //upload zip file to server
          const formData = new FormData();
          const blob = new Blob([content], { type: "application/pdf" });

          formData.append("file", blob);

          this.$axios
            .post("/pdf/splited_upload", formData)
            .then((response) => {
              console.log(response.data);
              this.$router.push({
                name: "download",
                params: {
                  id: response.data,
                  button_title: "Download split PDF",
                  dis_text: "PDF has been split!",
                  down_name: "splited_pdf.zip",
                  file_type: "application/zip",
                },
              });
            })
            .catch((e) => {
              console.log(e);
            });

          // Create a link and trigger the download
          // const link = document.createElement("a");
          // link.href = url;
          // link.download = "pdfden.zip";
          // document.body.appendChild(link);
          // link.click();
          // document.body.removeChild(link);
        });
      });
    },
  },
};
</script>

<style scoped>
.main {
  display: flex;
  flex-grow: 1;
  align-items: center;
  justify-content: center;
  text-align: center;
}

.page-title {
  margin-top: 50px;
  font-weight: 600;
  font-size: 42px;
  line-height: 52px;
  color: #33333b;
  text-align: center;
}

.page-description {
  max-width: 800px;
  margin: 8px auto 0;
  line-height: 32px;
  font-size: 22px;
  font-weight: 400;
  color: #47474f;
}

.dropzone-container {
  width: 100%;
  height: 100vh;
}
.dropzone-container {
  padding: 4rem;
  /* background: #f7fafc;
  border: 1px solid #e2e8f0; */
}

.upload_btn_area {
  position: relative;
}
.hidden-input {
  opacity: 0;
  overflow: hidden;
  position: absolute;
  width: 1px;
  height: 1px;
}
.file-label {
  font-size: 20px;
  display: block;
  cursor: pointer;
}
.preview-container {
  position: relative;
  margin-top: 2rem;
}

.preview_area {
  display: flex;
}
.preview-card {
  cursor: grab;
  flex: 1 1;
  margin: 4px;
  max-width: 165px;
  height: 215px;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-direction: column;
  flex-direction: column;
  -ms-flex-align: center;
  align-items: center;
  -ms-flex-line-pack: distribute;
  align-content: space-around;
  -ms-flex-pack: center;
  justify-content: center;
  position: relative;
  border: 1px solid rgba(0, 0, 0, 0);
  background: #fdfdfd;
  border-radius: 8px;
  -webkit-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.08);
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.08);
}

.preview-img {
  width: 140px;
  height: 180px;
  border-radius: 5px;
  border: 1px solid #a2a2a2;
  background-color: #a2a2a2;
}

.file__actions {
  top: 8px;
  right: 8px;
  position: absolute;
  display: inline-flex;
  /* display: none; */
  z-index: 100;
}
.file__btn {
  padding: 3px;
  width: 24px;
  height: 24px;
  -ms-flex: 0 0 24px;
  flex: 0 0 24px;
  text-align: center;
  background: rgba(0, 0, 0, 0.1);
  background: #ebebf4;
  margin-left: 4px;
  z-index: 1030;
  border-radius: 100%;
  cursor: pointer;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-align: center;
  align-items: center;
  -ms-flex-pack: center;
  justify-content: center;
}
.downloader__btn,
.uploader__btn {
  display: -ms-inline-flexbox;
  display: inline-flex;
  -ms-flex-align: center;
  align-items: center;
  -ms-flex-pack: center;
  justify-content: center;
  min-height: 80px;
  min-width: 330px;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  padding: 24px 48px;
  font-weight: 500;
  font-size: 24px;
  background: #e5322d;
  line-height: 28px;
  vertical-align: middle;
  color: #fff !important;
  text-decoration: none;
  margin-bottom: 12px;
  -webkit-transition: background-color 0.1s linear;
  -o-transition: background-color 0.1s linear;
  transition: background-color 0.1s linear;
  border: 0;
  border-radius: 12px;
  -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.14);
  box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.14);
  -ms-flex-order: 1;
  order: 1;
  max-width: 60vw;
}
.sidebar-active .tool__sidebar {
  -ms-flex-preferred-size: 440px;
  flex-basis: 440px;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-direction: column;
  flex-direction: column;
  padding: 0 0 120px;
  overflow-x: hidden;
  overflow-y: auto;
  position: relative;
}

#sidebar {
  max-width: 400px !important;
}

.tool__sidebar {
  height: 100vh;
  background-color: #fff;
}

.draggable-item {
  margin: 5px;
  padding: 10px;
  background-color: lightblue;
  cursor: move;
}

.upload_btn {
  width: fit-content;
  display: flex;
  text-align: center;
  margin: auto;
  position: relative;
  cursor: pointer;
}

.upload_btn .md-button-content {
  font-size: 22px;
  font-weight: 600;
  padding: 0 30px;
}

.add-more {
  width: fit-content;
  display: flex;
}

.add-more div {
  display: inline-block;
}

/* .dropbox {
  background-color: rgb(229, 50, 45) !important;
  height: 40px;
  width: 40px;
  padding: 11px;
  border-radius: 50%;
  cursor: pointer;
} */
/* 
.dropbox:hover {
  background-color: #e75651 !important;
} */

.option__panel__content {
  margin: 10px;
  background: #def2ff;
  padding: 10px;
  border-radius: 5px;
  font-size: 13px;
}

.option__panel__title {
  font-size: 22px;
  line-height: 26px;
  min-height: 48px;
  padding: 8px 12px;
  color: #fff;
  background-color: #e5322d;
  padding: 15px 40px;
  border-radius: 10px;
  font-weight: 600;
  border: none;
  cursor: pointer;
}

.option__panel__title:hover {
  background-color: #e75651;
}

#pickfiles {
  display: block;
  background-color: #e5322d;
  width: 40px;
  height: 40px;
  margin-bottom: 10px;
  padding: 10px;
  border-radius: 50%;
  cursor: pointer;
}

.add-more .md-icon-button {
  display: block;
  background-color: #e5322d !important;
  width: 40px;
  height: 40px;
  margin-bottom: 20px;
  padding: 8px;
  border-radius: 50%;
  cursor: pointer;
  border: none;
  color: #fff;
}
.social_btn {
  display: block;
  background-color: #e5322d !important;
  width: 40px;
  height: 40px;
  margin-bottom: 20px;
  padding: 8px;
  border-radius: 50%;
  cursor: pointer;
  border: none;
  color: #fff;
  margin-right: 10px;
}

.add-more .md-icon-button:hover,
.social_btn:hover {
  background-color: #e75651 !important;
}

.range__container {
  margin: 12px;
  padding: 12px;
  -ms-flex: 0 1 auto;
  flex: 0 1 auto;
  display: -ms-flexbox;
  display: block;
  -ms-flex-align: center;
  align-items: center;
  position: relative;
  overflow: hidden;
  border: 1px dashed #707078;
}

.split_card {
  display: inline-flex;
}

.page_number {
  display: block;
  margin-top: 10px;
}

.split_card_body {
  margin-left: 5px;
  margin-right: 5px;
}

h3 {
  font-weight: 500;
  margin-bottom: 50px;
}

.social_btn i {
  color: #fff !important;
}

.md-button-content,
.md-button-content i {
  color: #fff !important;
}

.badge {
  width: 19px;
  height: 19px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  top: 2px;
  right: 2px;
  background: red;
  border-radius: 100%;
  color: #fff;
  font-size: 10px;
  font-style: normal;
  font-weight: 600;
  letter-spacing: -0.05em;
  font-family: "Roboto Mono", monospace;
}
</style>
